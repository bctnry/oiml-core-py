# oiml-core

Parser for OpenIndented Markup Langugage (for Python)

## Testing

``` bash
python -m unittest ./tests/test.py
```


